package com.example.randomdraw;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.widget.*;
import androidx.exifinterface.media.ExifInterface;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_BASE=1000, COUNT=10;
    private static final long MAX_BYTES=240L*1024L;
    private final SecureRandom random=new SecureRandom();
    private final Uri[] uris=new Uri[COUNT];
    private final String[] names=new String[COUNT], exifs=new String[COUNT];
    private final long[] sizes=new long[COUNT];
    private final ImageView[] previews=new ImageView[COUNT];
    private final TextView[] statuses=new TextView[COUNT];
    private TextView summary, result;

    @Override public void onCreate(Bundle state) { super.onCreate(state); buildUi(); }

    private int dp(int n) { return Math.round(n*getResources().getDisplayMetrics().density); }

    private void buildUi() {
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(16),dp(16),dp(24)); scroll.addView(root);
        TextView title=new TextView(this); title.setText("السحب العشوائي — 10 مشاركين");
        title.setTextSize(23); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView intro=new TextView(this);
        intro.setText("اختر صورة لكل مشارك. يجب أن تكون 600 × 600 بكسل بالضبط، وحجمها أقل من 240 كيلوبايت.");
        intro.setTextSize(15); intro.setPadding(0,dp(10),0,dp(10)); root.addView(intro);
        summary=new TextView(this); summary.setTextSize(16); root.addView(summary);
        for(int i=0;i<COUNT;i++) {
            final int idx=i;
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(6),dp(6),dp(6),dp(6));
            row.setBackgroundColor(0xFFF1F3F5);
            ImageView image=new ImageView(this); image.setLayoutParams(new LinearLayout.LayoutParams(dp(70),dp(70)));
            image.setScaleType(ImageView.ScaleType.CENTER_CROP); previews[i]=image; row.addView(image);
            LinearLayout textCol=new LinearLayout(this); textCol.setOrientation(LinearLayout.VERTICAL);
            textCol.setPadding(dp(8),0,dp(4),0); textCol.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
            TextView label=new TextView(this); label.setText("المشارك "+(i+1)); label.setTextSize(16); textCol.addView(label);
            statuses[i]=new TextView(this); statuses[i].setText("لم تُختر صورة"); statuses[i].setTextSize(12); textCol.addView(statuses[i]);
            row.addView(textCol);
            Button choose=new Button(this); choose.setText("اختيار"); choose.setOnClickListener(v->pick(idx)); row.addView(choose);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(7); root.addView(row,lp);
        }
        Button draw=new Button(this); draw.setText("اسحب فائزًا عشوائيًا"); draw.setOnClickListener(v->drawWinner()); root.addView(draw);
        result=new TextView(this); result.setTextSize(16); result.setTextIsSelectable(true); result.setPadding(0,dp(12),0,dp(12)); root.addView(result);
        Button reset=new Button(this); reset.setText("إعادة ضبط"); reset.setOnClickListener(v->reset()); root.addView(reset);
        updateSummary(); result.setText("ستظهر النتيجة هنا."); setContentView(scroll);
    }

    private void pick(int idx) {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i,PICK_BASE+idx);
    }

    @Override protected void onActivityResult(int request,int code,Intent data) {
        super.onActivityResult(request,code,data);
        if(code!=RESULT_OK||data==null||data.getData()==null)return;
        int idx=request-PICK_BASE; if(idx<0||idx>=COUNT)return;
        Uri uri=data.getData();
        try {
            try { getContentResolver().takePersistableUriPermission(uri,data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            BitmapFactory.Options opt=new BitmapFactory.Options(); opt.inJustDecodeBounds=true;
            try(InputStream in=getContentResolver().openInputStream(uri)) {
                if(in==null)throw new Exception("تعذر قراءة الصورة");
                BitmapFactory.decodeStream(in,null,opt);
            }
            if(opt.outWidth!=600||opt.outHeight!=600) {
                Toast.makeText(this,"مرفوضة: يجب أن تكون الأبعاد 600 × 600 بالضبط.",Toast.LENGTH_LONG).show(); return;
            }
            long bytes=fileSize(uri);
            if(bytes<0||bytes>=MAX_BYTES) {
                Toast.makeText(this,"مرفوضة: يجب أن يكون الحجم أقل من 240 KiB.",Toast.LENGTH_LONG).show(); return;
            }
            uris[idx]=uri; names[idx]=fileName(uri); sizes[idx]=bytes; exifs[idx]=readExif(uri);
            previews[idx].setImageURI(uri);
            statuses[idx].setText(String.format(Locale.ROOT,"600 × 600 | %.1f KB | مقبولة",bytes/1024.0));
            updateSummary(); result.setText("قُبلت صورة المشارك "+(idx+1)+".");
        } catch(Exception e) { Toast.makeText(this,"تعذر التحقق من الصورة: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private long fileSize(Uri uri) {
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.SIZE},null,null,null)) {
            if(c!=null&&c.moveToFirst()) { int col=c.getColumnIndex(OpenableColumns.SIZE); if(col>=0&&!c.isNull(col))return c.getLong(col); }
        } catch(Exception ignored) {}
        try(InputStream in=getContentResolver().openInputStream(uri)) {
            if(in==null)return -1; long total=0; byte[] b=new byte[8192]; int n;
            while((n=in.read(b))!=-1) { total+=n; if(total>=MAX_BYTES)return total; } return total;
        } catch(Exception e) { return -1; }
    }

    private String fileName(Uri uri) {
        try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) {
            if(c!=null&&c.moveToFirst()) { int col=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(col>=0)return c.getString(col); }
        } catch(Exception ignored) {}
        return uri.getLastPathSegment()==null?"اسم غير متاح":uri.getLastPathSegment();
    }

    private String readExif(Uri uri) {
        try(InputStream in=getContentResolver().openInputStream(uri)) {
            if(in==null)return "بيانات EXIF غير متاحة";
            ExifInterface exif=new ExifInterface(in);
            String[] tags={ExifInterface.TAG_DATETIME_ORIGINAL,ExifInterface.TAG_DATETIME,ExifInterface.TAG_MAKE,
                ExifInterface.TAG_MODEL,ExifInterface.TAG_SOFTWARE,ExifInterface.TAG_LENS_MODEL,
                ExifInterface.TAG_FOCAL_LENGTH,ExifInterface.TAG_ORIENTATION};
            StringBuilder out=new StringBuilder();
            for(String tag:tags) { String value=exif.getAttribute(tag); if(value!=null&&!value.trim().isEmpty()) {
                if(out.length()>0)out.append("\n"); out.append(tag).append(": ").append(value);
            }}
            return out.length()==0?"لا توجد بيانات EXIF مقروءة":out.toString();
        } catch(Exception e) { return "تعذر قراءة بيانات EXIF"; }
    }

    private void drawWinner() {
        List<Integer> ready=new ArrayList<>();
        for(int i=0;i<COUNT;i++)if(uris[i]!=null)ready.add(i);
        if(ready.size()!=COUNT) { Toast.makeText(this,"اختر 10 صور مقبولة أولًا. المختار: "+ready.size()+"/10",Toast.LENGTH_LONG).show(); return; }
        int w=ready.get(random.nextInt(ready.size()));
        result.setText("الفائز: المشارك "+(w+1)+"\nاسم الملف: "+names[w]+"\nالأبعاد: 600 × 600 بكسل"+
            String.format(Locale.ROOT,"\nالحجم: %.1f KB (%d بايت)",sizes[w]/1024.0,sizes[w])+
            "\n\nبيانات EXIF الموجودة فعلًا:\n"+exifs[w]);
    }

    private void updateSummary() { int n=0; for(Uri u:uris)if(u!=null)n++; summary.setText("الصور المقبولة: "+n+" من 10"); }
    private void reset() {
        for(int i=0;i<COUNT;i++){uris[i]=null;names[i]=null;exifs[i]=null;sizes[i]=0;previews[i].setImageDrawable(null);statuses[i].setText("لم تُختر صورة");}
        updateSummary(); result.setText("ستظهر النتيجة هنا.");
    }
}
