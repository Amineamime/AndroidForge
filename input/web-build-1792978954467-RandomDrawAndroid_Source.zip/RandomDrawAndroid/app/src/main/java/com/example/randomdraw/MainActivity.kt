package com.example.randomdraw

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import java.security.SecureRandom
import java.util.Locale

class MainActivity : Activity() {
    private val pickRequest = 4201
    private val requiredCount = 10
    private val maxBytes = 240 * 1024 // strictly less than 240 KiB
    private val selected = mutableListOf<ParticipantImage>()
    private lateinit var status: TextView
    private lateinit var listText: TextView
    private lateinit var resultImage: ImageView
    private lateinit var resultText: TextView
    private lateinit var drawButton: Button

    data class ParticipantImage(
        val uri: Uri,
        val fileName: String,
        val bytes: Long,
        val width: Int,
        val height: Int
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(24))
            setBackgroundColor(Color.WHITE)
        }
        scroll.addView(root)
        setContentView(scroll)

        fun heading(text: String, size: Float = 18f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(Color.rgb(25, 35, 50))
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(8))
            }

        root.addView(heading("القرعة العشوائية", 25f))
        root.addView(heading("أضف 10 صور مطابقة للشروط ثم اسحب فائزًا واحدًا.", 15f))

        val addButton = Button(this).apply {
            text = "اختيار الصور"
            setOnClickListener { chooseImages() }
        }
        root.addView(addButton, matchWrap())

        status = heading("", 15f)
        root.addView(status)

        listText = heading("", 14f)
        root.addView(listText)

        drawButton = Button(this).apply {
            text = "إجراء القرعة"
            isEnabled = false
            setOnClickListener { drawWinner() }
        }
        root.addView(drawButton, matchWrap())

        resultImage = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = ImageView.GONE
            setBackgroundColor(Color.rgb(245, 245, 245))
        }
        root.addView(resultImage, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(280)
        ).apply { topMargin = dp(12) })

        resultText = heading("", 15f)
        root.addView(resultText)
    }

    private fun chooseImages() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, pickRequest)
    }

    @Deprecated("Uses the classic activity result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickRequest || resultCode != Activity.RESULT_OK || data == null) return

        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } ?: data.data?.let { uris.add(it) }

        if (uris.isEmpty()) {
            status.text = "لم يتم اختيار أي صورة."
            return
        }

        val candidates = mutableListOf<ParticipantImage>()
        val errors = mutableListOf<String>()
        for (uri in uris.distinct()) {
            if (candidates.size + selected.size >= requiredCount) break
            try {
                val bytes = getFileSize(uri)
                if (bytes >= maxBytes) {
                    errors.add("${getFileName(uri)}: الحجم يجب أن يكون أقل من 240 كيلوبايت.")
                    continue
                }
                val bounds = contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.Options().run {
                        inJustDecodeBounds = true
                        BitmapFactory.decodeStream(it, null, this)
                        Pair(outWidth, outHeight)
                    }
                } ?: throw IllegalArgumentException("تعذر قراءة الصورة")
                if (bounds.first != 600 || bounds.second != 600) {
                    errors.add("${getFileName(uri)}: الأبعاد ${bounds.first}×${bounds.second} وليست 600×600.")
                    continue
                }
                candidates.add(
                    ParticipantImage(uri, getFileName(uri), bytes, bounds.first, bounds.second)
                )
            } catch (e: Exception) {
                errors.add("${getFileName(uri)}: تعذر التحقق من الملف.")
            }
        }

        selected.addAll(candidates)
        status.text = if (errors.isEmpty()) {
            "تم قبول ${candidates.size} صورة."
        } else {
            "تم قبول ${candidates.size} صورة. الصور المرفوضة:\n" + errors.joinToString("\n")
        }
        resultImage.visibility = ImageView.GONE
        resultText.text = ""
        refreshUi()
    }

    private fun getFileSize(uri: Uri): Long {
        contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val index = c.getColumnIndex(OpenableColumns.SIZE)
                if (index >= 0 && !c.isNull(index)) return c.getLong(index)
            }
        }
        return contentResolver.openInputStream(uri)?.use { input ->
            var total = 0L
            val buffer = ByteArray(8192)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
            }
            total
        } ?: 0L
    }

    private fun getFileName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i) ?: "صورة"
            }
        }
        return uri.lastPathSegment ?: "صورة"
    }

    private fun refreshUi() {
        status.text = if (selected.size == requiredCount) {
            "اكتملت الصور العشر. يمكنك إجراء القرعة."
        } else {
            "الصور المقبولة: ${selected.size} من $requiredCount"
        }
        listText.text = if (selected.isEmpty()) "" else selected.mapIndexed { i, p ->
            "${i + 1}. ${p.fileName} — ${String.format(Locale.US, "%.1f", p.bytes / 1024.0)} KB"
        }.joinToString("\n")
        drawButton.isEnabled = selected.size == requiredCount
    }

    private fun drawWinner() {
        if (selected.size != requiredCount) {
            status.text = "يجب قبول 10 صور بالضبط قبل القرعة."
            return
        }
        // SecureRandom supplies an unbiased bounded integer for the ten equally likely entries.
        val winner = selected[SecureRandom().nextInt(selected.size)]
        try {
            contentResolver.openInputStream(winner.uri)?.use { stream ->
                resultImage.setImageBitmap(BitmapFactory.decodeStream(stream))
            }
            resultImage.visibility = ImageView.VISIBLE

            val exifText = try {
                contentResolver.openInputStream(winner.uri)?.use { stream ->
                    val exif = ExifInterface(stream)
                    val date = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                    val camera = exif.getAttribute(ExifInterface.TAG_MODEL)
                    val make = exif.getAttribute(ExifInterface.TAG_MAKE)
                    buildList {
                        if (!make.isNullOrBlank()) add("الشركة المصنّعة: $make")
                        if (!camera.isNullOrBlank()) add("طراز الكاميرا: $camera")
                        if (!date.isNullOrBlank()) add("تاريخ التصوير المسجّل: $date")
                    }.joinToString("\n").ifBlank { "لا توجد بيانات EXIF متاحة في الملف." }
                } ?: "تعذر قراءة بيانات الصورة."
            } catch (_: Exception) {
                "لا توجد بيانات EXIF متاحة أو تعذرت قراءتها."
            }

            resultText.text = "الفائز العشوائي\n${winner.fileName}\n" +
                "الأبعاد: ${winner.width}×${winner.height} بكسل\n" +
                "حجم الملف: ${String.format(Locale.US, "%.2f", winner.bytes / 1024.0)} كيلوبايت\n" +
                exifText
        } catch (_: Exception) {
            resultText.text = "تعذّر عرض الصورة الفائزة."
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(6); bottomMargin = dp(6) }
}
